# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module ModeloQytetet
  module Tipo_moneda
      EURO_ESP = :euro_esp
      EURO_IT = :euro_it
      EUROS2_ESP = :euros2_esp
      CTS50_ESP =  :cts50_esp
  end
end
