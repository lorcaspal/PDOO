# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

module ModeloQytetet
  module Tipo_billete
      EUROS5_ESP = :euros5_esp
      EUROS50_ESP = :euros50_esp
      EUROS100_FR = :euros100_fr
      EUROS50_D = :euros50_d
  end
end
